module.exports=[70406,(e,t,p)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))}];

//# sourceMappingURL=%5Bexternals%5D_next_dist_compiled_%40opentelemetry_api_2f2eda7e._.js.map