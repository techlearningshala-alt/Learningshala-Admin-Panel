globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/5d091104600cfcc6.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/e728a2207a3f89fe.css",
      "static/chunks/turbopack-3465effd31ed2fd1.js"
    ],
    "/_app": [
      "static/chunks/ff796e5ad78a8470.js",
      "static/chunks/97678e778af522ef.js",
      "static/chunks/0199750984bc1583.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/efae8da4a94ee9ed.js",
      "static/chunks/a492c8a8af9a68a6.css",
      "static/chunks/6de34474fd0a9658.css",
      "static/chunks/d44c7a1a57583a03.css",
      "static/chunks/turbopack-4b7b7a185fdd260c.js"
    ],
    "/_error": [
      "static/chunks/fe2281f6f6a4d035.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/turbopack-e3f56de18756d5d5.js"
    ],
    "/courses": [
      "static/chunks/98914b352f644dd9.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/e62eb54a42926bc5.js",
      "static/chunks/turbopack-78f31dbdb06252fd.js"
    ],
    "/dashboard": [
      "static/chunks/ed50f5c1f7296700.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/ff796e5ad78a8470.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-1f327da0f95a3a6c.js"
    ],
    "/dashboard/layout": [
      "static/chunks/ae7ba69cd6d37071.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/ff796e5ad78a8470.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-7404c1671f33b8a6.js"
    ],
    "/domains": [
      "static/chunks/c0b7fbbdf9c0a310.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-44f24b277c392b1b.js"
    ],
    "/emi-partners": [
      "static/chunks/c3409a63b81f959d.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-81c9b1baa147ef0f.js"
    ],
    "/faq-category": [
      "static/chunks/efebfefbd7be23ea.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/2678cf233c98cc62.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/turbopack-2211c5d940372621.js"
    ],
    "/faqs": [
      "static/chunks/b135f54ad73c175e.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/783b0a634bb80cfe.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-5e4ac0957b100bc6.js"
    ],
    "/login": [
      "static/chunks/e35d571b633fbace.js",
      "static/chunks/ff796e5ad78a8470.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-c1ccd8ae074859b3.js"
    ],
    "/media-spotlight": [
      "static/chunks/f7690b6c29b19495.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-120a81fd0ee72938.js"
    ],
    "/mentors": [
      "static/chunks/1c073cf66e55935f.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-ee4adad0a628a8aa.js"
    ],
    "/placements": [
      "static/chunks/2934aaa9b1c4dadc.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-e5caaf9bbfa5b86d.js"
    ],
    "/specializations": [
      "static/chunks/24a45a785a5ccf79.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/e62eb54a42926bc5.js",
      "static/chunks/turbopack-ae130b40ff14ae10.js"
    ],
    "/testimonials": [
      "static/chunks/ad01c3a1cd0a30cb.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-9330941f01f8945c.js"
    ],
    "/universities": [
      "static/chunks/e39af518504ab04d.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/e62eb54a42926bc5.js",
      "static/chunks/783b0a634bb80cfe.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/98f7101ff95629bc.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-18f45b7ac61337e5.js"
    ],
    "/universities-approvals": [
      "static/chunks/8961a69eccca8a4b.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-068fe45cc61b7280.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];