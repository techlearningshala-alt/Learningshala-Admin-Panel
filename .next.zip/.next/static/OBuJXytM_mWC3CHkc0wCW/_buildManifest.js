self.__BUILD_MANIFEST = {
  "/": [
    "./static/chunks/fe2606992454436d.js"
  ],
  "/_error": [
    "./static/chunks/e49ef2b75db9e73a.js"
  ],
  "/courses": [
    "./static/chunks/270473f4d52a44c3.js"
  ],
  "/dashboard": [
    "./static/chunks/7384d1a309305d91.js"
  ],
  "/dashboard/layout": [
    "./static/chunks/cda5ca10c5adfb7e.js"
  ],
  "/domains": [
    "./static/chunks/c29244069208a777.js"
  ],
  "/emi-partners": [
    "./static/chunks/a693c8853efd4e01.js"
  ],
  "/faq-category": [
    "./static/chunks/d03f12ec0b8e2b7e.js"
  ],
  "/faqs": [
    "./static/chunks/f9af2b628e44419a.js"
  ],
  "/login": [
    "./static/chunks/57157c4cbd49ae3d.js"
  ],
  "/media-spotlight": [
    "./static/chunks/55eb32cf71d30a9b.js"
  ],
  "/mentors": [
    "./static/chunks/7191ab41027158bf.js"
  ],
  "/placements": [
    "./static/chunks/936ffd48eab68cb2.js"
  ],
  "/specializations": [
    "./static/chunks/327f9a7780b33f82.js"
  ],
  "/testimonials": [
    "./static/chunks/4e984036f7438ce8.js"
  ],
  "/universities": [
    "./static/chunks/538e06cb1fa73970.js"
  ],
  "/universities-approvals": [
    "./static/chunks/2839b72874ec6ee2.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/hello",
    "/courses",
    "/dashboard",
    "/dashboard/layout",
    "/domains",
    "/emi-partners",
    "/faq-category",
    "/faqs",
    "/login",
    "/media-spotlight",
    "/mentors",
    "/placements",
    "/specializations",
    "/testimonials",
    "/universities",
    "/universities-approvals"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()