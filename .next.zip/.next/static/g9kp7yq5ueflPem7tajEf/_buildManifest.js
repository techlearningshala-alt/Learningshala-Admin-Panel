self.__BUILD_MANIFEST = {
  "/": [
    "./static/chunks/fe2606992454436d.js"
  ],
  "/_error": [
    "./static/chunks/e49ef2b75db9e73a.js"
  ],
  "/courses": [
    "./static/chunks/270473f4d52a44c3.js"
  ],
  "/dashboard": [
    "./static/chunks/8ee9a9d305be4a96.js"
  ],
  "/dashboard/layout": [
    "./static/chunks/6e0ac631b05c32dc.js"
  ],
  "/domains": [
    "./static/chunks/c29244069208a777.js"
  ],
  "/emi-partners": [
    "./static/chunks/a693c8853efd4e01.js"
  ],
  "/faq-category": [
    "./static/chunks/5d3fc62e99b573c7.js"
  ],
  "/faqs": [
    "./static/chunks/6d33d269491e7deb.js"
  ],
  "/login": [
    "./static/chunks/5d80b1f39e4f1d26.js"
  ],
  "/media-spotlight": [
    "./static/chunks/67f98345336254c6.js"
  ],
  "/mentors": [
    "./static/chunks/bfda03109d670e90.js"
  ],
  "/placements": [
    "./static/chunks/936ffd48eab68cb2.js"
  ],
  "/specializations": [
    "./static/chunks/327f9a7780b33f82.js"
  ],
  "/testimonials": [
    "./static/chunks/0a4fe8f1d362352f.js"
  ],
  "/universities": [
    "./static/chunks/538e06cb1fa73970.js"
  ],
  "/universities-approvals": [
    "./static/chunks/2839b72874ec6ee2.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/hello",
    "/courses",
    "/dashboard",
    "/dashboard/layout",
    "/domains",
    "/emi-partners",
    "/faq-category",
    "/faqs",
    "/login",
    "/media-spotlight",
    "/mentors",
    "/placements",
    "/specializations",
    "/testimonials",
    "/universities",
    "/universities-approvals"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()