__turbopack_load_page_chunks__("/_error", [
  "static/chunks/fe2281f6f6a4d035.js",
  "static/chunks/670e9f4c13748b89.js",
  "static/chunks/2ea8cc66105251ca.js",
  "static/chunks/turbopack-e3f56de18756d5d5.js"
])
