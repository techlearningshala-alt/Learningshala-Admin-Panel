__turbopack_load_page_chunks__("/", [
  "static/chunks/5d091104600cfcc6.js",
  "static/chunks/670e9f4c13748b89.js",
  "static/chunks/2ea8cc66105251ca.js",
  "static/chunks/e728a2207a3f89fe.css",
  "static/chunks/turbopack-3465effd31ed2fd1.js"
])
