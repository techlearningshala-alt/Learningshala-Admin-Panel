globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/5d091104600cfcc6.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/e728a2207a3f89fe.css",
      "static/chunks/turbopack-3465effd31ed2fd1.js"
    ],
    "/_app": [
      "static/chunks/ff796e5ad78a8470.js",
      "static/chunks/f8460dcd7ff464b9.js",
      "static/chunks/0199750984bc1583.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/efae8da4a94ee9ed.js",
      "static/chunks/a492c8a8af9a68a6.css",
      "static/chunks/6de34474fd0a9658.css",
      "static/chunks/d44c7a1a57583a03.css",
      "static/chunks/turbopack-dced96fcf678f198.js"
    ],
    "/_error": [
      "static/chunks/fe2281f6f6a4d035.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/turbopack-e3f56de18756d5d5.js"
    ],
    "/courses": [
      "static/chunks/98914b352f644dd9.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/e62eb54a42926bc5.js",
      "static/chunks/turbopack-78f31dbdb06252fd.js"
    ],
    "/dashboard": [
      "static/chunks/09d060581caf5ad0.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/ff796e5ad78a8470.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-c87950d3c603ccbc.js"
    ],
    "/dashboard/layout": [
      "static/chunks/06d0155fe3cdbc0e.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/ff796e5ad78a8470.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-ad371b6ed62e5b95.js"
    ],
    "/domains": [
      "static/chunks/c0b7fbbdf9c0a310.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-44f24b277c392b1b.js"
    ],
    "/emi-partners": [
      "static/chunks/c3409a63b81f959d.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-81c9b1baa147ef0f.js"
    ],
    "/faq-category": [
      "static/chunks/3cfcaee90958688c.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/2678cf233c98cc62.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/turbopack-33d8b6c0820a06a9.js"
    ],
    "/faqs": [
      "static/chunks/18194a2b921b434a.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/9eb75d791d54cb35.js",
      "static/chunks/783b0a634bb80cfe.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-057e87c6f673ab0d.js"
    ],
    "/login": [
      "static/chunks/1d434667ef5e12fe.js",
      "static/chunks/ff796e5ad78a8470.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-20e813ed8845806a.js"
    ],
    "/media-spotlight": [
      "static/chunks/5386fe50802a3c5a.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-815541df5dc7b9be.js"
    ],
    "/mentors": [
      "static/chunks/905b8d7ec5e55d8c.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-e360a14c927051d4.js"
    ],
    "/placements": [
      "static/chunks/2934aaa9b1c4dadc.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-e5caaf9bbfa5b86d.js"
    ],
    "/specializations": [
      "static/chunks/24a45a785a5ccf79.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/e62eb54a42926bc5.js",
      "static/chunks/turbopack-ae130b40ff14ae10.js"
    ],
    "/testimonials": [
      "static/chunks/e9fc1464827f3bab.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-410f1687adfbb29c.js"
    ],
    "/universities": [
      "static/chunks/e39af518504ab04d.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/e62eb54a42926bc5.js",
      "static/chunks/783b0a634bb80cfe.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/98f7101ff95629bc.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/turbopack-18f45b7ac61337e5.js"
    ],
    "/universities-approvals": [
      "static/chunks/8961a69eccca8a4b.js",
      "static/chunks/4491fed0a1e80345.js",
      "static/chunks/05d91c65a48349c3.js",
      "static/chunks/2ea8cc66105251ca.js",
      "static/chunks/670e9f4c13748b89.js",
      "static/chunks/446ec6b5f48b1ed0.js",
      "static/chunks/3b32103cc7bf93e1.js",
      "static/chunks/turbopack-068fe45cc61b7280.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];