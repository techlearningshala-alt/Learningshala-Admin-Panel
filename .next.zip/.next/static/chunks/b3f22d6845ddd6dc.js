__turbopack_load_page_chunks__("/mentors", [
  "static/chunks/1c073cf66e55935f.js",
  "static/chunks/446ec6b5f48b1ed0.js",
  "static/chunks/05d91c65a48349c3.js",
  "static/chunks/670e9f4c13748b89.js",
  "static/chunks/4491fed0a1e80345.js",
  "static/chunks/2ea8cc66105251ca.js",
  "static/chunks/3b32103cc7bf93e1.js",
  "static/chunks/turbopack-ee4adad0a628a8aa.js"
])
