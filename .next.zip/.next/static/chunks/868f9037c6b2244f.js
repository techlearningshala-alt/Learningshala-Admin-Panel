__turbopack_load_page_chunks__("/login", [
  "static/chunks/e35d571b633fbace.js",
  "static/chunks/ff796e5ad78a8470.js",
  "static/chunks/2ea8cc66105251ca.js",
  "static/chunks/670e9f4c13748b89.js",
  "static/chunks/4491fed0a1e80345.js",
  "static/chunks/turbopack-c1ccd8ae074859b3.js"
])
