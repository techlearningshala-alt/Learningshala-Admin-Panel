__turbopack_load_page_chunks__("/_app", [
  "static/chunks/ff796e5ad78a8470.js",
  "static/chunks/f8460dcd7ff464b9.js",
  "static/chunks/0199750984bc1583.js",
  "static/chunks/9eb75d791d54cb35.js",
  "static/chunks/2ea8cc66105251ca.js",
  "static/chunks/670e9f4c13748b89.js",
  "static/chunks/3b32103cc7bf93e1.js",
  "static/chunks/efae8da4a94ee9ed.js",
  "static/chunks/a492c8a8af9a68a6.css",
  "static/chunks/6de34474fd0a9658.css",
  "static/chunks/d44c7a1a57583a03.css",
  "static/chunks/turbopack-dced96fcf678f198.js"
])
