__turbopack_load_page_chunks__("/faq-category", [
  "static/chunks/efebfefbd7be23ea.js",
  "static/chunks/05d91c65a48349c3.js",
  "static/chunks/2678cf233c98cc62.js",
  "static/chunks/9eb75d791d54cb35.js",
  "static/chunks/446ec6b5f48b1ed0.js",
  "static/chunks/2ea8cc66105251ca.js",
  "static/chunks/4491fed0a1e80345.js",
  "static/chunks/670e9f4c13748b89.js",
  "static/chunks/turbopack-2211c5d940372621.js"
])
