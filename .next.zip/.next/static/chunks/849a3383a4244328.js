__turbopack_load_page_chunks__("/dashboard/layout", [
  "static/chunks/ae7ba69cd6d37071.js",
  "static/chunks/3b32103cc7bf93e1.js",
  "static/chunks/ff796e5ad78a8470.js",
  "static/chunks/9eb75d791d54cb35.js",
  "static/chunks/2ea8cc66105251ca.js",
  "static/chunks/670e9f4c13748b89.js",
  "static/chunks/4491fed0a1e80345.js",
  "static/chunks/turbopack-7404c1671f33b8a6.js"
])
