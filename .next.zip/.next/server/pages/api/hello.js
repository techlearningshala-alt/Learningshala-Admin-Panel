var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/hello.js")
R.c("server/chunks/[externals]_next_dist_compiled_@opentelemetry_api_2f2eda7e._.js")
R.c("server/chunks/[root-of-the-server]__dc3b946a._.js")
R.m(31492)
module.exports=R.m(31492).exports
