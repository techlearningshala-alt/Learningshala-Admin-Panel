__turbopack_load_page_chunks__("/faqs", [
  "static/chunks/7e3f145ff608112d.js",
  "static/chunks/05d91c65a48349c3.js",
  "static/chunks/3b32103cc7bf93e1.js",
  "static/chunks/9eb75d791d54cb35.js",
  "static/chunks/783b0a634bb80cfe.js",
  "static/chunks/670e9f4c13748b89.js",
  "static/chunks/2ea8cc66105251ca.js",
  "static/chunks/4491fed0a1e80345.js",
  "static/chunks/turbopack-02f9ca86d5c84232.js"
])
