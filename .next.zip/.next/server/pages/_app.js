var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__82e7a549._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e608cb61._.js")
R.c("server/chunks/ssr/[root-of-the-server]__9b40d981._.js")
R.m(76695)
module.exports=R.m(76695).exports
