var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__d626e26f._.js")
R.c("server/chunks/ssr/[root-of-the-server]__105fcb0f._.js")
R.c("server/chunks/ssr/[root-of-the-server]__f31d659c._.js")
R.m(67684)
module.exports=R.m(67684).exports
