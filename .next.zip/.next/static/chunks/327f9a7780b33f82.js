__turbopack_load_page_chunks__("/specializations", [
  "static/chunks/24a45a785a5ccf79.js",
  "static/chunks/446ec6b5f48b1ed0.js",
  "static/chunks/05d91c65a48349c3.js",
  "static/chunks/670e9f4c13748b89.js",
  "static/chunks/2ea8cc66105251ca.js",
  "static/chunks/4491fed0a1e80345.js",
  "static/chunks/e62eb54a42926bc5.js",
  "static/chunks/turbopack-ae130b40ff14ae10.js"
])
