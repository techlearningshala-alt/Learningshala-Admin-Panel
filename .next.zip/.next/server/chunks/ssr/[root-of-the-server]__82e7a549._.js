module.exports=[8171,(a,b,c)=>{b.exports=a.x("react/jsx-runtime",()=>require("react/jsx-runtime"))},27669,(a,b,c)=>{b.exports=a.x("react",()=>require("react"))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__82e7a549._.js.map